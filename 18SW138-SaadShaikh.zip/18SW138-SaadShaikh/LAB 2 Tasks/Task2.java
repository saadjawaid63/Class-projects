class Task2{
	public static void main(String args[]){
		int a=5,b=6;
		boolean c,d=true,e=false;
		//Relational Operator:
		System.out.println("Relational Operators:");
		System.out.println();
		c=a>b;
		System.out.println(c);
		c=a<b;
		System.out.println(c);
		c=a>=b;
		System.out.println(c);
		c=a<=b;
		System.out.println(c);
		c=a==b;
		System.out.println(c);
		c=a!=b;
		System.out.println(c);
		System.out.println();
		System.out.println("Logical Boolean Operators:");
		//Logical Boolean Operator:
		System.out.println();
		c=d&e;
		System.out.println(c);
		c=d|e;
		System.out.println(c);
		c=!d;
		System.out.println(c);
		c=!e;
		System.out.println(c);
		c=d^e;
		System.out.println(c);
	}
}