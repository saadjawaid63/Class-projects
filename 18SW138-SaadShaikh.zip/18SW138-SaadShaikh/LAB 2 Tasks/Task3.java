class Task3{
	public static void main(String args[]){
		double a=5.50,b=6.06,c=9.04,d=10.30,e=2.10;
		double sum=a+b+c+d+e;
		double average=(sum/5);
		System.out.println("Numbers are:"+a+" "+b+" "+c+" "+d+" "+e);
		System.out.println("Sum of Numbers:"+sum);
		System.out.println("Average:"+average);
	}
}