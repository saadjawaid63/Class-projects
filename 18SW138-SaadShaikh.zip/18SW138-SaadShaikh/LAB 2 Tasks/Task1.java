class Task1{
	public static void main(String args[]){
		String name=args[0];
		String roll_no=args[1];
		System.out.println("Name:"+name);
		System.out.println("Roll No:"+roll_no);
	}
}