class Task4{
	public static void main(String args[]){
		double PI=3.14;
		double radius=10;
		double diameter=2*radius;
		double circumference=diameter*PI;
		double area=circumference*radius/2;
		System.out.println("Radius of Circle:"+radius);
		System.out.println("Diameter of Circle:"+diameter);
		System.out.println("Circumference of Circle:"+circumference);
		System.out.println("Area of Circle:"+area);
	}
}