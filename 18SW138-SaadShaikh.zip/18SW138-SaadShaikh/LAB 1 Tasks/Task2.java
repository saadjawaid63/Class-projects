class Task2{
	public static void main(String args[]){
		double var1=50.25;
		System.out.println("Orignal Value:"+var1);
		System.out.println("Integer Part:"+(int)var1);
		System.out.println("Float part:"+(var1%=(int)var1));
	}
}